__version__ = '0.7.1'  # from 0.7.0

VERSION = __version__
